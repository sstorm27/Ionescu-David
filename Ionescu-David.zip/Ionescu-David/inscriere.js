/**
 * Funcție pentru simularea înscrierii la un turneu.
 *
 * @param {string} tournamentName Numele turneului la care se înscrie utilizatorul.
 */
function enrollInTournament(tournamentName) {
    // 1. Loghează acțiunea
    console.log(`Tentativă de înscriere la turneul: ${tournamentName}`);

    // 2. Simulează verificarea autentificării utilizatorului (de ex: un token)
    // Aici, în mod real, ar trebui să verifici dacă user-ul este logat.
    const isUserLoggedIn = true; // Să presupunem că este logat
    if (!isUserLoggedIn) {
        alert("Trebuie să fii autentificat pentru a te înscrie la un turneu!");
        // Redirecționează către pagina de login
        // window.location.href = 'login.html';
        return;
    }

    // 3. Simulează trimiterea cererii de înscriere către server
    // (Aici ar trebui să fie un apel AJAX/Fetch către un API backend)
    const success = Math.random() > 0.1; // 90% șanse de succes pentru demo

    if (success) {
        // 4. Afișează confirmarea și actualizează interfața (simulat)
        const message = `Felicitări! Te-ai înscris la turneul: "${tournamentName}". Verifică-ți profilul!`;
        alert(message);
        console.log(message);
        
        // Simulează adăugarea turneului la profilul utilizatorului
        updateProfileTournaments(tournamentName);

    } else {
        // 5. Tratează erorile (simulat)
        const errorMessage = `Eroare la înscriere la "${tournamentName}". Poate ești deja înscris sau înscrierile s-au închis.`;
        alert(errorMessage);
        console.error(errorMessage);
    }
}

/**
 * Funcție de suport pentru a simula actualizarea listei de turnee la care ai participat
 * pe pagina de profil (dacă elementul există).
 */
function updateProfileTournaments(newTournament) {
    // ID-ul listei <ul> din "profil utilizator.html"
    const ulElement = document.getElementById('tournaments-list');
    
    if (ulElement) {
        const li = document.createElement('li');
        li.textContent = `${newTournament} - Înregistrat`;
        ulElement.appendChild(li);
        console.log(`Profil actualizat cu: ${newTournament}`);
    }
}


// EXEMPLU DE UTILIZARE:
// Dacă ai un buton pe o pagină de turnee:
// <button onclick="enrollInTournament('Turneul de League of Legends - Septembrie')">Înscrie-te</button>